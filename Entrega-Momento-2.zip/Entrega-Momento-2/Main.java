// ----------------------------------------------------------------
// Imports

import java.util.List;
import java.util.Scanner;

// ----------------------------------------------------------------
// Clase

    public class Main {

    static Biblioteca biblioteca = new Biblioteca();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion = -1;

        while (opcion != 0) {
            System.out.println("\n===== SISTEMA DE BIBLIOTECA =====");
            System.out.println("1. Agregar libro");
            System.out.println("2. Agregar usuario (Cliente / Administrador)");
            System.out.println("3. Reservar libro");
            System.out.println("4. Devolver libro");
            System.out.println("5. Ver libros");
            System.out.println("6. Ver usuarios");
            System.out.println("7. Ver reservas");
            System.out.println("8. Eliminar libro");
            System.out.println("9. Eliminar usuario");
            System.out.println("0. Salir");
            System.out.print("Opción: ");

            try {
                opcion = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Opción inválida.");
                continue;
            }

            switch (opcion) {
                case 1 -> agregarLibro();
                case 2 -> agregarUsuario();
                case 3 -> reservarLibro();
                case 4 -> devolverLibro();
                case 5 -> verLibros();
                case 6 -> verUsuarios();
                case 7 -> verReservas();
                case 8 -> eliminarLibro();
                case 9 -> eliminarUsuario();
                case 0 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción no válida.");
            }
        }
    }

// ----------------------------------------------------------------

    static void agregarLibro() {
        System.out.print("Código: ");
        String codigo = sc.nextLine();
        System.out.print("Título: ");
        String titulo = sc.nextLine();
        System.out.print("Autor: ");
        String autor = sc.nextLine();

        biblioteca.agregarLibro(new Libro(codigo, titulo, autor, true));
    }

    static void agregarUsuario() {
        System.out.println("Tipo de usuario:");
        System.out.println("  1. Cliente");
        System.out.println("  2. Administrador");
        System.out.print("Opción: ");
        String tipo = sc.nextLine();

        System.out.print("Documento: ");
        String documento = sc.nextLine();
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();

        Usuario nuevo;
        if (tipo.equals("2")) {
            nuevo = new Administrador(documento, nombre);
        } else {
            nuevo = new Cliente(documento, nombre);
        }

        biblioteca.agregarUsuario(nuevo);
    }

    static void reservarLibro() {
        System.out.print("Documento del usuario: ");
        String documento = sc.nextLine();
        System.out.print("Código del libro: ");
        String codigo = sc.nextLine();

        biblioteca.reservarLibro(documento, codigo);
    }

    static void devolverLibro() {
        System.out.print("Código del libro: ");
        String codigo = sc.nextLine();
        biblioteca.devolverLibro(codigo);
    }

    static void eliminarLibro() {
        System.out.print("Código del libro a eliminar: ");
        String codigo = sc.nextLine();
        biblioteca.eliminarLibro(codigo);
    }

    static void eliminarUsuario() {
        System.out.print("Documento del usuario a eliminar: ");
        String documento = sc.nextLine();
        biblioteca.eliminarUsuario(documento);
    }

    static void verLibros() {
        List<Libro> libros = biblioteca.getLibros();
        if (libros.isEmpty()) {
            System.out.println("No hay libros registrados.");
        } else {
            System.out.println("\n--- LISTA DE LIBROS ---");
            for (Libro l : libros) {
                System.out.println(l.mostrar());
            }
        }
    }

    static void verUsuarios() {
        List<Usuario> usuarios = biblioteca.getUsuarios();
        if (usuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
        } else {
            System.out.println("\n--- LISTA DE USUARIOS ---");
            for (Usuario u : usuarios) {
                biblioteca.mostrarInfoUsuario(u);
            }
        }
    }

    static void verReservas() {
        List<Reserva> reservas = biblioteca.getReservas();
        if (reservas.isEmpty()) {
            System.out.println("No hay reservas registradas.");
        } else {
            System.out.println("\n--- LISTA DE RESERVAS ---");
            for (Reserva r : reservas) {
                System.out.println(r.mostrar());
            }
        }
    }
}