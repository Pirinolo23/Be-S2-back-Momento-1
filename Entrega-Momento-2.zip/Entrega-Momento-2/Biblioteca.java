// ----------------------------------------------------------------
// Clase

    public class Biblioteca {

    private GestorLibros gestorLibros = new GestorLibros();
    private GestorUsuarios gestorUsuarios = new GestorUsuarios();
    private GestorReservas gestorReservas = new GestorReservas();

// ----------------------------------------------------------------
// Libros

    public void agregarLibro(Libro libro) {
        if (gestorLibros.buscar(libro.getCodigo()) != null) {
            System.out.println("Ya existe un libro con ese código.");
            return;
        }
        gestorLibros.guardar(libro);
        System.out.println("Libro agregado correctamente.");
    }

    public void eliminarLibro(String codigo) {
        if (gestorLibros.eliminar(codigo)) {
            System.out.println("Libro eliminado.");
        } else {
            System.out.println("No se encontró el libro.");
        }
    }

    public Libro buscarLibro(String codigo) {
        return gestorLibros.buscar(codigo);
    }

    public java.util.List<Libro> getLibros() {
        return gestorLibros.listar();
    }

// ----------------------------------------------------------------
// Usuarios

    public void agregarUsuario(Usuario usuario) {
        if (gestorUsuarios.buscar(usuario.getDocumento()) != null) {
            System.out.println("Ya existe un usuario con ese documento.");
            return;
        }
        gestorUsuarios.guardar(usuario);
        System.out.println("Usuario agregado correctamente.");
    }

    public void eliminarUsuario(String documento) {
        if (gestorUsuarios.eliminar(documento)) {
            System.out.println("Usuario eliminado.");
        } else {
            System.out.println("No se encontró el usuario.");
        }
    }

    public Usuario buscarUsuario(String documento) {
        return gestorUsuarios.buscar(documento);
    }

    public java.util.List<Usuario> getUsuarios() {
        return gestorUsuarios.listar();
    }

// ----------------------------------------------------------------
// Reservas

    public void reservarLibro(String documento, String codigoLibro) {
        Usuario usuario = buscarUsuario(documento);
        Libro libro = buscarLibro(codigoLibro);

        if (usuario == null) {
            System.out.println("El usuario no existe.");
            return;
        }
        if (libro == null) {
            System.out.println("El libro no existe.");
            return;
        }
        if (!libro.isDisponible()) {
            System.out.println("El libro ya está prestado.");
            return;
        }

        if (!usuario.puedeReservar()) {
            System.out.println("El rol " + usuario.getRol() + " no puede realizar reservas.");
            return;
        }

        libro.setDisponible(false);
        gestorReservas.guardar(new Reserva(usuario, libro));
        System.out.println("Reserva realizada con éxito.");
    }

    public void devolverLibro(String codigoLibro) {
        Libro libro = buscarLibro(codigoLibro);

        if (libro == null) {
            System.out.println("El libro no existe.");
            return;
        }
        if (libro.isDisponible()) {
            System.out.println("El libro no está prestado.");
            return;
        }

        libro.setDisponible(true);
        gestorReservas.eliminar(codigoLibro);
        System.out.println("Libro devuelto correctamente.");
    }

    public java.util.List<Reserva> getReservas() {
        return gestorReservas.listar();
    }

// ----------------------------------------------------------------    
// Metodo
    public void mostrarInfoUsuario(Usuario u) {
        System.out.println("→ " + u.mostrar() + " | Puede reservar: " + u.puedeReservar());
    }
}