// ----------------------------------------------------------------
// Clase

public abstract class Usuario {
    protected String nombre;
    protected String documento;


// ----------------------------------------------------------------
// Constructores

    public Usuario() {
    }

    public Usuario(String nombre, String documento) {
        this.nombre = nombre;
        this.documento = documento;
    }

// ----------------------------------------------------------------
// Getters y Setters

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

// ----------------------------------------------------------------
// Metodos

        public abstract String getRol();

    public abstract boolean puedeReservar();

    public String mostrar() {
        return "[" + getRol() + "] " + documento + " - " + nombre;
    }
}