// ----------------------------------------------------------------
// Clase

    public class Libro {

// ----------------------------------------------------------------
// Atributos

        private String codigo;
        private String titulo;
        private String autor;
        private boolean disponible;

// ----------------------------------------------------------------
// Constructores

        public Libro() {
        }

        public Libro(String codigo, String titulo, String autor, boolean disponible) {
            this.codigo = codigo;
            this.titulo = titulo;
            this.autor = autor;
            this.disponible = disponible;
    }

// ----------------------------------------------------------------
// Getters y Setters

        public String getCodigo() {
            return codigo;
        }

        public void setCodigo(String codigo) {
            this.codigo = codigo;
        }

        public String getTitulo() {
            return titulo;
        }

        public void setTitulo(String titulo) {
            this.titulo = titulo;
        }

        public String getAutor() {
            return autor;
        }

        public void setAutor(String autor) {
            this.autor = autor;
        }

        public boolean isDisponible() {
            return disponible;
        }

        public void setDisponible(boolean disponible) {
            this.disponible = disponible;
        }

// ----------------------------------------------------------------
// Metodos

    public String mostrar() {
        String estado = disponible ? "Disponible" : "Prestado";
        return codigo + " - " + titulo + " (" + autor + ") [" + estado + "]";
    }
}
