public interface IOperaciones<T, K>{
    
    void guardar(T objeto);

    T buscar(K clave);

    boolean eliminar(K clave);

    java.util.List<T> listar();
    
}
