// ----------------------------------------------------------------
// Imports

    import java.util.ArrayList;
    import java.util.List;

// ----------------------------------------------------------------
// Clase

    public class GestorLibros implements IOperaciones<Libro, String> {

    private List<Libro> libros = new ArrayList<>();

    @Override
    public void guardar(Libro libro) {
        libros.add(libro);
    }

    @Override
    public Libro buscar(String codigo) {
        for (Libro l : libros) {
            if (l.getCodigo().equalsIgnoreCase(codigo)) {
                return l;
            }
        }
        return null;
    }

    @Override
    public boolean eliminar(String codigo) {
        Libro l = buscar(codigo);
        if (l != null) {
            libros.remove(l);
            return true;
        }
        return false;
    }

    @Override
    public List<Libro> listar() {
        return libros;
    }
}