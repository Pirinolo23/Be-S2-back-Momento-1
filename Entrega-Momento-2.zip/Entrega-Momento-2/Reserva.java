// ----------------------------------------------------------------
// Clase

    public class Reserva {

// ----------------------------------------------------------------
// Atributos

        private Usuario usuario;
        private Libro libro;

// ----------------------------------------------------------------
// Constructores

        public Reserva() {
        }

        public Reserva(Usuario usuario, Libro libro) {
            this.usuario = usuario;
            this.libro = libro;
    }

// ----------------------------------------------------------------
// Getters y Setters

        public Usuario getUsuario() {
            return usuario;
        }

        public void setUsuario(Usuario usuario) {
            this.usuario = usuario;
        }

        public Libro getLibro() {
            return libro;
        }

        public void setLibro(Libro libro) {
            this.libro = libro;
        }

// ----------------------------------------------------------------
// Metodos

    public String mostrar() {
    return usuario.getNombre() + " (" + usuario.getRol() + ") reservó "
            + libro.getTitulo() + "\"";
    }
}