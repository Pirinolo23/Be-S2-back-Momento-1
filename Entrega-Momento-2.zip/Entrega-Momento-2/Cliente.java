// ----------------------------------------------------------------
// Clase

    public class Cliente extends Usuario {

// ----------------------------------------------------------------
// Constructores

        public Cliente() {
        }

        public Cliente(String nombre, String documento) {
            super(nombre, documento);
        }

// ----------------------------------------------------------------
// Metodos

        @Override
        public String getRol() {
            return "Cliente";
        }

        @Override
        public boolean puedeReservar() {
            return true;
        }
}