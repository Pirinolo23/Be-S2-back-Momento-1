// ----------------------------------------------------------------
// Imports

    import java.util.ArrayList;
    import java.util.List;

// ----------------------------------------------------------------
// Clase

    public class GestorReservas implements IOperaciones<Reserva, String> {

    private List<Reserva> reservas = new ArrayList<>();

    @Override
    public void guardar(Reserva reserva) {
        reservas.add(reserva);
    }

    @Override
    public Reserva buscar(String codigoLibro) {
        for (Reserva r : reservas) {
            if (r.getLibro().getCodigo().equalsIgnoreCase(codigoLibro)) {
                return r;
            }
        }
        return null;
    }

    @Override
    public boolean eliminar(String codigoLibro) {
        Reserva r = buscar(codigoLibro);
        if (r != null) {
            reservas.remove(r);
            return true;
        }
        return false;
    }

    @Override
    public List<Reserva> listar() {
        return reservas;
    }
}
