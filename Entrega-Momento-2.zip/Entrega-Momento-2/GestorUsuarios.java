// ----------------------------------------------------------------
// Imports

    import java.util.ArrayList;
    import java.util.List;

// ----------------------------------------------------------------
// Clase

    public class GestorUsuarios implements IOperaciones<Usuario, String> {
    
    private List<Usuario> usuarios = new ArrayList<>();

    @Override
    public void guardar(Usuario usuario) {
        usuarios.add(usuario);
    }

    @Override
    public Usuario buscar(String documento) {
        for (Usuario u : usuarios) {
            if (u.getDocumento().equalsIgnoreCase(documento)) {
                return u;
            }
        }
        return null;
    }

    @Override
    public boolean eliminar(String documento) {
        Usuario u = buscar(documento);
        if (u != null) {
            usuarios.remove(u);
            return true;
        }
        return false;
    }

    @Override
    public List<Usuario> listar() {
        return usuarios;
    }
    
}
