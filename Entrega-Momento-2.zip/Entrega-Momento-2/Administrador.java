// ----------------------------------------------------------------
// Clase

    public class Administrador extends Usuario {

// ----------------------------------------------------------------
// Constructores

        public Administrador() {
        }

        public Administrador(String nombre, String documento) {
            super(nombre, documento);
    }

// ----------------------------------------------------------------
// Metodos

        @Override
        public String getRol() {
            return "Administrador";
        }

        @Override
        public boolean puedeReservar() {
            return false;
        }
}