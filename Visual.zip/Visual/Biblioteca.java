// ---------------------------------------------------------------------------------------------------------

    // Imports

    import java.util.ArrayList;
    import java.util.List;

    // ---------------------------------------------------------------------------------------------------------

    // Clase

    public class Biblioteca {

    // ---------------------------------------------------------------------------------------------------------

    // Array List
    private List<Libro> libros;
    private List<Usuario> usuarios;
    private List<Reserva> reservas;

    // ---------------------------------------------------------------------------------------------------------

    // Constructor

    public Biblioteca() {
        libros = new ArrayList<>();
        usuarios = new ArrayList<>();
        reservas = new ArrayList<>();
    }

    // ---------------------------------------------------------------------------------------------------------

    // Libros

    public void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    public Libro buscarLibro(String codigo) {
        for (Libro l : libros) {
            if (l.getCodigo().equals(codigo)) {
                return l;
            }
        }
        return null;
    }

    public List<Libro> getLibros() {
        return libros;
    }

    // ---------------------------------------------------------------------------------------------------------

    // Usuarios

    public void agregarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    public Usuario buscarUsuario(String documento) {
        for (Usuario u : usuarios) {
            if (u.getDocumento().equals(documento)) {
                return u;
            }
        }
        return null;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    // ---------------------------------------------------------------------------------------------------------

    // Reservas

    public void reservarLibro(String documento, String codigoLibro) {
        Usuario usuario = buscarUsuario(documento);
        Libro libro = buscarLibro(codigoLibro);

        if (usuario == null) {
            System.out.println("El Usuario no extiste");
            return;
        }
        if (libro == null) {
            System.out.println("El libro no existe");
            return;
        }
        if (libro.isDisponible()) {
            System.out.println("El libro esta prestado");
            return;
        }

        libro.setDisponible(false);
        reservas.add(new Reserva(usuario, libro));
    }

    public void devolverLibro(String codigoLibro) {
        Libro libro = buscarLibro(codigoLibro);

        if (libro == null) {
            System.out.println("El libro no existe");
            return;
        }
        if (libro.isDisponible()) {
            System.out.println("El libro no esta prestado");
            return;
        }

        libro.setDisponible(true);
    }

    public List<Reserva> getReservas() {
        return reservas;
    }
}