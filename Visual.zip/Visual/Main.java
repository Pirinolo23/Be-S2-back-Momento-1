// ---------------------------------------------------------------------------------------------------------

    //Imports

    import java.util.Scanner;

    // ---------------------------------------------------------------------------------------------------------

    // Clase

    public class Main {

    // ---------------------------------------------------------------------------------------------------------

    static Biblioteca biblioteca = new Biblioteca();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion = -1;

        while (opcion != 0) {
            System.out.println("Biblioteca");
            System.out.println("1. Agregar libro 📕");
            System.out.println("2. Agregar usuario 🧑");
            System.out.println("3. Reservar libro 📚");
            System.out.println("4. Devolver libro 📖");
            System.out.println("5. Ver libros 📚");
            System.out.println("6. Ver usuarios 🧑");
            System.out.println("7. Ver reservas");
            System.out.println("0. Salir ➡️");
            System.out.println("Opción: ");

            opcion = Integer.parseInt(sc.nextLine());

            if (opcion == 1) {
                agregarLibro();
            } else if (opcion == 2) {
                agregarUsuario();
            } else if (opcion == 3) {
                reservarLibro();
            } else if (opcion == 4) {
                devolverLibro();
            } else if (opcion == 5) {
                verLibros();
            } else if (opcion == 6) {
                verUsuarios();
            } else if (opcion == 7) {
                verReservas();
            } else if (opcion == 0) {
                System.out.println("Saliendo con exitó ✅");
            } else {
                System.out.println("Opción no válida ❌.");
            }
        }
    }

// ---------------------------------------------------------------------------------------------------------

    static void agregarLibro() {
        System.out.println("Código: ");
        String codigo = sc.nextLine();
        System.out.println("Título: ");
        String titulo = sc.nextLine();
        System.out.println("Autor: ");
        String autor = sc.nextLine();

        biblioteca.agregarLibro(new Libro(codigo, titulo, autor, true));
        System.out.println("Libro agregado");
    }

    static void agregarUsuario() {
        System.out.println("Documento: ");
        String documento = sc.nextLine();
        System.out.println("Nombre: ");
        String nombre = sc.nextLine();
        System.out.println("Edad: ");
        int edad = Integer.parseInt(sc.nextLine());

        biblioteca.agregarUsuario(new Usuario(documento, nombre, edad));
        System.out.println("Usuario agregado");
    }

    static void reservarLibro() {
        System.out.println("Documento del usuario: ");
        String documento = sc.nextLine();
        System.out.println("Código del libro: ");
        String codigo = sc.nextLine();

        biblioteca.reservarLibro(documento, codigo);
        System.out.println("Reserva realizada con exitó ✅");
    }

    static void devolverLibro() {
        System.out.println("Código del libro: ");
        String codigo = sc.nextLine();

        biblioteca.devolverLibro(codigo);
        System.out.println("Libro devuelto con exitó ✅");
    }

    static void verLibros() {
        if (biblioteca.getLibros().isEmpty()) {
            System.out.println("No hay libros ❌📕");
        } else {
            for (Libro l : biblioteca.getLibros()) {
                System.out.println(l.mostrar());
            }
        }
    }

    static void verUsuarios() {
        if (biblioteca.getUsuarios().isEmpty()) {
            System.out.println("No hay usuarios ❌🧑");
        } else {
            for (Usuario u : biblioteca.getUsuarios()) {
                System.out.println(u.mostrar());
            }
        }
    }

    static void verReservas() {
        if (biblioteca.getReservas().isEmpty()) {
            System.out.println("No hay reservas ❌");
        } else {
            for (Reserva r : biblioteca.getReservas()) {
                System.out.println(r.mostrar());
            }
        }
    }
}