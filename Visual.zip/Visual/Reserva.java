// ---------------------------------------------------------------------------------------------------------

    // Clase

    public class Reserva {

    private Usuario usuario;
    private Libro libro;

    // ---------------------------------------------------------------------------------------------------------

    // Constructores

    public Reserva() {
    }

    public Reserva(Usuario usuario, Libro libro) {
        setUsuario(usuario);
        setLibro(libro);
    }

    // ---------------------------------------------------------------------------------------------------------

    // Getters

    public Usuario getUsuario() {
        return usuario;
    }

    public Libro getLibro() {
        return libro;
    }

    // ---------------------------------------------------------------------------------------------------------

    // Setters con validaciones

    public void setUsuario(Usuario usuario) {
        if (usuario == null) {
            System.out.println("Error: el usuario no puede estar vacío.");
            return;
        }
        this.usuario = usuario;
    }

    public void setLibro(Libro libro) {
        if (libro == null) {
            System.out.println("Error: el libro no puede estar vacío.");
            return;
        }
        this.libro = libro;
    }

    // ---------------------------------------------------------------------------------------------------------

    // Método

    public String mostrar() {
        return usuario.getNombre() + " reservó " + libro.getTitulo();
    }
}