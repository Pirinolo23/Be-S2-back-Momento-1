// ---------------------------------------------------------------------------------------------------------

    // Clase

    public class Usuario {

    private String documento;
    private String nombre;
    private int edad;

    // ---------------------------------------------------------------------------------------------------------

    // Constructores

    public Usuario() {
    }

    public Usuario(String documento, String nombre, int edad) {
        setDocumento(documento);
        setNombre(nombre);
        setEdad(edad);
    }

    // ---------------------------------------------------------------------------------------------------------

    // Getters

    public String getDocumento() {
        return documento;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    // ---------------------------------------------------------------------------------------------------------

    // Setters con validaciones

    public void setDocumento(String documento) {
        if (documento == null || documento.isEmpty()) {
            System.out.println("Error: el documento no puede estar vacío");
            return;
        }
        this.documento = documento;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.isEmpty()) {
            System.out.println("Error: el nombre no puede estar vacío");
            return;
        }
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        if (edad < 0) {
            System.out.println("Error: la edad no puede ser negativa");
            return;
        }
        if (edad > 100) {
            System.out.println("Error: la edad ingresada no es válida");
            return;
        }
        this.edad = edad;
    }

    // ---------------------------------------------------------------------------------------------------------

    // Método

    public String mostrar() {
        return documento + " - " + nombre + " (" + edad + " años)";
    }
}