// ---------------------------------------------------------------------------------------------------------

    // Clase

    public class Libro {

    private String codigo;
    private String titulo;
    private String autor;
    private boolean disponible;

    // ---------------------------------------------------------------------------------------------------------

    // Constructores

    public Libro() {
    }

    public Libro(String codigo, String titulo, String autor, boolean disponible) {
        setCodigo(codigo);
        setTitulo(titulo);
        setAutor(autor);
        this.disponible = disponible;
    }

    // ---------------------------------------------------------------------------------------------------------

    // Getters

    public String getCodigo() {
        return codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public boolean isDisponible() {
        return disponible;
    }

    // ---------------------------------------------------------------------------------------------------------

    // Setters con validaciones

    public void setCodigo(String codigo) {
        if (codigo == null || codigo.isEmpty()) {
            System.out.println("Error: el código no puede estar vacío.");
            return;
        }
        this.codigo = codigo;
    }

    public void setTitulo(String titulo) {
        if (titulo == null || titulo.isEmpty()) {
            System.out.println("Error: el título no puede estar vacío.");
            return;
        }
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        if (autor == null || autor.isEmpty()) {
            System.out.println("Error: el autor no puede estar vacío.");
            return;
        }
        this.autor = autor;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    // ---------------------------------------------------------------------------------------------------------

    // Método

    public String mostrar() {
        String estado = disponible ? "Disponible" : "Prestado";
        return codigo + " - " + titulo + " (" + autor + ") [" + estado + "]";
    }
}